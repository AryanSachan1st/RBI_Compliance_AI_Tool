import cv2

def calculate_blur_score(image_path):

    image = cv2.imread(image_path)

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )

    score = cv2.Laplacian(
        gray,
        cv2.CV_64F
    ).var()

    return score


def quality_label(score):

    if score > 100:
        return "Good"

    elif score > 50:
        return "Average"

    else:
        return "Poor"
