import cv2

def detect_signature(image_path):

    image = cv2.imread(image_path)

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )

    edges = cv2.Canny(
        gray,
        100,
        200
    )

    signature_pixels = cv2.countNonZero(
        edges
    )

    if signature_pixels > 5000:

        return True

    return False
