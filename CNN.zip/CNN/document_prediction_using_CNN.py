import tensorflow as tf
import numpy as np

model = tf.keras.models.load_model(
    "models/authenticity_model.h5"
)

CLASSES = [
    "Loan_Agreement",
    "Insurance_Policy",
    "KYC_Form",
    "Other"
]

def predict_document(image_path):

    image = tf.keras.utils.load_img(
        image_path,
        target_size=(224,224)
    )

    image_array = tf.keras.utils.img_to_array(image)

    image_array = np.expand_dims(
        image_array,
        axis=0
    )

    prediction = model.predict(
        image_array,
        verbose=0
    )

    index = np.argmax(prediction)

    confidence = np.max(prediction)

    return CLASSES[index], confidence
