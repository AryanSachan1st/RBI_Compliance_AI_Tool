from pdf_converter import convert_pdf_to_images
from quality_checker import *
from document_classifier import *
from signature_detector import *
from authenticity_engine import *

images = convert_pdf_to_images(
    "loan_agreement.pdf",
    "extracted_images"
)

for image in images:

    blur_score = calculate_blur_score(
        image
    )

    quality = quality_label(
        blur_score
    )

    doc_type, conf = predict_document(
        image
    )

    signature = detect_signature(
        image
    )

    authenticity = authenticity_score(
        quality,
        conf,
        signature
    )

    print("Type:", doc_type)
    print("Quality:", quality)
    print("Authenticity:", authenticity)
