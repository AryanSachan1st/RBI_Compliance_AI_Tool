import streamlit as st
from cnn_module.authenticity_pipeline import run_authenticity_check
import os

st.title("AI Compliance Tool")

uploaded_file = st.file_uploader(
    "Upload PDF",
    type=["pdf"]
)

if uploaded_file:

    os.makedirs("uploads", exist_ok=True)

    pdf_path = os.path.join(
        "uploads",
        uploaded_file.name
    )

    with open(pdf_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    st.success("PDF Uploaded")

    results = run_authenticity_check(pdf_path)

    for page_result in results:

        st.subheader("Authenticity Analysis")

        st.write(
            f"Document Type: {page_result['document_type']}"
        )

        st.write(
            f"Quality: {page_result['quality']}"
        )

        st.write(
            f"Signature Present: {page_result['signature']}"
        )

        st.write(
            f"Classification Confidence: {page_result['confidence']} %"
        )

        st.metric(
            "Authenticity Score",
            page_result['authenticity_score']
        )
