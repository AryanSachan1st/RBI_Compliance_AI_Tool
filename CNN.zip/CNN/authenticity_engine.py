def authenticity_score(
        quality,
        confidence,
        signature
):

    score = 0

    if quality == "Good":
        score += 40

    elif quality == "Average":
        score += 20

    score += confidence * 40

    if signature:
        score += 20

    return round(score,2)
