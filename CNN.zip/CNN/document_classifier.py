import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras import models

IMG_SIZE = 224

train_dataset = tf.keras.preprocessing.image_dataset_from_directory(
    "dataset",
    image_size=(224,224),
    batch_size=32
)

model = models.Sequential([

    layers.Rescaling(1./255),

    layers.Conv2D(
        32,
        (3,3),
        activation='relu'
    ),

    layers.MaxPooling2D(),

    layers.Conv2D(
        64,
        (3,3),
        activation='relu'
    ),

    layers.MaxPooling2D(),

    layers.Conv2D(
        128,
        (3,3),
        activation='relu'
    ),

    layers.MaxPooling2D(),

    layers.Flatten(),

    layers.Dense(
        128,
        activation='relu'
    ),

    layers.Dense(
        4,
        activation='softmax'
    )
])

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

model.fit(
    train_dataset,
    epochs=10
)

model.save("authenticity_model.h5")
